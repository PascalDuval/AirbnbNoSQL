Suite à l'indisponiblité de la fonction d'exportation.
je vous invite à retrouver me présentation en ligne à l'URL suivante : https://app.presentations.ai/view/XbJZJTPuWw 
Celle-ci risque d'évoluerjnusqu'au jour du bilan. 
Toutefois 95% de son contenu ne bougera pas.
